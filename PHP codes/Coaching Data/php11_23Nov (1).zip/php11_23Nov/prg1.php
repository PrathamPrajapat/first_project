<html>
<body>
<form method="post">
 roll no.<input type="text" name="rno"
    required>            
 <br>            
 name<input type="text" name="name"
    required>            
 <br>            
 age<input type="text" name="age"
    required>            
 <br>            
 <input type="submit" name="b1"
    value="click here">            
 <br>            
</form>
<?php
//
$rno=$_POST["rno"];
$name=$_POST["name"];
$age=$_POST["age"];

//step 1 for establish connection
$con= mysqli_connect("localhost","root","",
        "batch11db");
if(!$con)
{
    die("connection failed");
}

//step 2 write insert query
$query="insert into student values($rno,'$name',$age)";

//step 3 for execute query
mysqli_query($con,$query);

?>

    
    </body>
</html>       


