<html>
<body>
<form method="post">
 roll no.<input type="text" name="rno"
   required >            
 <br>            
 name<input type="text" name="name"
   required >            
 <br>            
 age<input type="text" name="age"
  required  >            
 <br>            
 <input type="submit" name="b1"
    value="click here">            
 <br>            
</form>
<?php
if(isset($_POST["b1"]))
{
$rno=$_POST["rno"];
$name=$_POST["name"];
$age=$_POST["age"];

//step 1 for establish connection
$con= mysqli_connect("localhost","root","",
        "batch11db");
if(!$con)
{
    die("connection failed");
}

//step 2 write insert query
$query="insert into student values($rno,'$name',$age)";

//step 3 for execute query
mysqli_query($con,$query);

//step 4 for chekc no. of affected rows
$n=mysqli_affected_rows($con);
if($n>0)
echo "record saved";
else
    echo "record not save";
}
?>

    
    </body>
</html>       


