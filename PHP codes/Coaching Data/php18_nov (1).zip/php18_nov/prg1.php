<?php
$s="this is a string function";

echo ucwords($s)."<br>";
echo ucfirst($s)."<br>";

?>

