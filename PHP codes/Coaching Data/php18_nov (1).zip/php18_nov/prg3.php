<?php
$s1="xyz";
//$s2="abc";
$s2="Xyz";

//$n=strcmp($s1, $s2);
$n= strcasecmp($s1, $s2);

if($n==0)
  echo "both string are equal";
elseif($n<0)
  echo "string1 < string2";
else
  echo "string1 > string2"; 


?>
