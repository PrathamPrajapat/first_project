<html>
    <body>
        <form>
enter First no.<input type="text" 
name="a" required>
<br>
enter second no.<input type="text" 
name="b" required>
<br>

<input type="submit"  name="b1"
       value="find max">
        </form>
<?php
$a=$_GET["a"];
$b=$_GET["b"];
if($a>$b)
    echo "a is max";
else 
    echo "b is max";

?>
    </body>
</html>
