<?php
$s="sunset.jpg";
$a= explode(".", $s);
echo "<pre>";
print_r($a);

$nm=time().".".$a[1];
echo $nm;


?>
