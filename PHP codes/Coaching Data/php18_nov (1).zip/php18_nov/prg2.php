<?php
$s="abc123*";
echo str_shuffle($s);


?>
