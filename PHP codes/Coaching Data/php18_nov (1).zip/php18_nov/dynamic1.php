<html>
    <body>
        <form>
enter any value<input type="text" 
name="a" required>
<br>
<input type="submit"  name="b1"
       value="click here">
        </form>
<?php
$a=$_GET["a"];
//echo $a;
echo "square root =".($a*$a);
?>
    </body>
</html>
