<html>
    <body>
        <form>
enter First no.<input type="text" 
name="a" required>
<br>
enter second no.<input type="text" 
name="b" required>
<br>

<input type="submit"  name="b1"
       value="sum">
        </form>
<?php
$a=$_GET["a"];
$b=$_GET["b"];

echo "sum=".($a+$b)."<br>";
echo "sub=".($a-$b)."<br>";
echo "multiply=".($a*$b)."<br>";
echo "div=".($a/$b)."<br>";
echo "mod=".($a%$b)."<br>";

?>
    </body>
</html>
