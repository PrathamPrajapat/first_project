<?php
//$s="abc";
//echo str_replace("a", "x", $s);

//$s="door";
//echo str_replace("o", "e", $s);

$s="this is a test string.test data";
//echo str_replace("test", "demo", $s);
echo str_ireplace("Test", "demo", $s);

?>
