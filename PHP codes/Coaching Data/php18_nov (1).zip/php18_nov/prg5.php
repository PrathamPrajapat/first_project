<?php
$dt="2022/11/18";

$a=explode("/", $dt);
echo "<pre>";
print_r($a);

$dt1=$a[2]."/".$a[1]."/".$a[0];
echo $dt1;

?>
