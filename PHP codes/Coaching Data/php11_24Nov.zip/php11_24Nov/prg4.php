<html>
<body>
<form method="post">
 roll no.<input type="text" name="rno"
   required >            
 <br>            
 <input type="submit" name="search"
    value="search">            
 <br>            
</form>
<?php
if(isset($_POST["search"]))
{
$rno=$_POST["rno"];

//step 1 for establish connection
$con= mysqli_connect("localhost","root","",
        "batch11db");
if(!$con)
{
    die("connection failed");
}

//step 2 write search query
$query="select * from student where rno=$rno";

//step 3 for execute query
$result=mysqli_query($con, $query);

$n=mysqli_num_rows($result);
if($n>0)
{
    //step 4 for fetch record
    $a= mysqli_fetch_array($result);
    echo "<pre>";
    print_r($a);
}
else
    echo "record not found";
}
?>

    
    </body>
</html>       


