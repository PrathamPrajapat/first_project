<html>
<body>
<form method="post">
 roll no.<input type="text" name="rno"
   required >            
 <br>            
 <input type="submit" name="delete"
    value="delete">            
 <br>            
</form>
<?php
if(isset($_POST["delete"]))
{
$rno=$_POST["rno"];

//step 1 for establish connection
$con= mysqli_connect("localhost","root","",
        "batch11db");
if(!$con)
{
    die("connection failed");
}

//step 2 write delete query
$query="delete from student where rno=$rno";

//step 3 for execute query
mysqli_query($con, $query);

//step 4 for chekc affected rows
$n= mysqli_affected_rows($con);

if($n>0)
    echo "record deleted";
else
    echo "record not found";

}
?>

    
    </body>
</html>       


