<?php
$s="test";

echo $s."<br>"; //test
echo "$s<br>"; //test
echo '$s<br>'; //$s
echo "$$s"; //$test

?>
