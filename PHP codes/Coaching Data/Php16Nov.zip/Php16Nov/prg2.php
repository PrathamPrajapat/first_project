<?php
$a=array(10,20,30,40,50);
$b=array(25,40,45,75,20);

//for array search ...................
$s=40;
$res=array_search($s, $a);
echo $res;
//....................................

//$c=  array_intersect($a, $b);
//$c=  array_diff($a, $b);
//echo "<pre>";
//print_r($c);

?>
