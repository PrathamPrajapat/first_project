<?php
echo date("d")."<br>";
echo date("m")."<br>";
echo date("y")."<br>";

echo date("D")."<br>";
echo date("M")."<br>";
echo date("Y")."<br>";

echo date("l")."<br>";
echo date("F")."<br>";
echo date("j")."<br>";

echo date("d-m-y")."<br>";
echo date("D,d-m-Y")."<br>";
echo date("D,d-m-Y,H:i:s a")."<br>";
echo date("D,d-m-Y,H:i:s A")."<br>";

?>