<?php
$a=array(10,20,30,40,50,60,70);

echo "<pre>";
print_r($a);

$b=array_chunk($a, 4);
echo "<pre>";
print_r($b);

?>