<?php
$s="this is a string fuNction demo";

echo $s."<br>";
echo strtoupper($s)."<br>";
echo strtolower($s)."<br>";
echo ucwords($s)."<br>";
echo ucfirst($s)."<br>";

?>