<?php
$product=array(
array("id"=>1,"nm"=>"cpu"),    
array("id"=>2,"nm"=>"cd"),
array("id"=>3,"nm"=>"dvd")    
);

echo "<pre>";
print_r($product);

?>