<?php
$product=array(
array("nm"=>"cpu","qty"=>5,"price"=>20000),    
array("nm"=>"cd","qty"=>3,"price"=>10),
array("nm"=>"dvd","qty"=>7,"price"=>150)    
);

foreach($product as $p)
{
    //echo "<pre>";  print_r($p);
    $total=$p["qty"]*$p["price"];
    echo $total."<br>";
}

?>