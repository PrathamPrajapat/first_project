<?php
$a=array(10,20,30);
echo "<pre>";
print_r($a);

array_push($a,40,50);
echo "<pre>";
print_r($a);

array_pop($a);
echo "<pre>";
print_r($a);

array_pop($a);
echo "<pre>";
print_r($a);

?>