<?php
$a=array("a"=>10,"b"=>20,"c"=>30);
echo "<pre>";
print_r($a);

$b=array_flip($a);
echo "<pre>";
print_r($b);


?>