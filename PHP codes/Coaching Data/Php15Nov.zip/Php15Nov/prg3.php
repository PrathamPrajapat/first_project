<?php
$student=array("rno"=>1,"name"=>"ram",
    "age"=>15,"city"=>"indore");

echo "<pre>";
print_r($student);


?>