<?php
$a=array(10,20,30,40,50);

$s=array_sum($a);
echo "sum=".$s;

?>