<?php
$a=array("c"=>8,"a"=>11,"b"=>6);
echo "<pre>";
print_r($a);

//sort($a);
//asort($a);
//rsort($a);
//arsort($a);
//ksort($a);
krsort($a);
echo "<pre>";
print_r($a);

?>
