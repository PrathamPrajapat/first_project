<?php
$student["rno"]=1;
$student["name"]="ram";
$student["age"]=20;
$student["address"]="13,mig";
$student["city"]="Indore";

foreach ($student as $key => $value) 
{
 echo $key."=>".$value."<br>";    
}

?>