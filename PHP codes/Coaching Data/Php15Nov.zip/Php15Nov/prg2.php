<?php
$student["rno"]=1;
$student["name"]="ram";
$student["age"]=20;
$student["address"]="13,mig";
$student["city"]="Indore";

echo "<pre>";
var_dump($student);

echo "<pre>";
print_r($student);

?>