<div id='categories'>
<div class="container">
        <h2 class="heading text-center" id="categories">Categories We Serve</h2>
    <div class="row">
        <!--1st card-->
        <div class="card col-md-4 mt-3">
  <img src="./images/snacksnoodles.webp" class="card-img-top" alt="Snacks Images">
  <div class="card-body">
    <h5 class="card-title">Snacks</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="snacks.php" class="btn btn-primary">View More</a>
  </div>
</div>
        <!--2nd card-->
           <div class="card col-md-4 mt-3">
  <img src="./images/breakfastaaloo.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Breakfast</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="breakfast.php" class="btn btn-primary">View More</a>
  </div>
</div>
        <!--3rd card-->
           <div class="card col-md-4 mt-3">
  <img src="./images/beveragescold.png" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Beverages</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="beverages.php" class="btn btn-primary">View More</a>
  </div>
</div>
    </div>
        <!--bottom row-->
            <div class="row">
                <!--4th card-->
              <div class="card col-md-6 mt-3">
  <img src="./images/lunchpack.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Lunch</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="lunch.php" class="btn btn-primary">View More</a>
  </div>
</div>
                <!--5th card-->
                <div class="card col-md-6 mt-3">
  <img src="./images/dinnerpaneer.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Dinner</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="dinner.php" class="btn btn-primary">View More</a>
  </div>
</div>
                <!--end-->
            </div>
        </div>
    </div>
</div>
    <br>
    <br>