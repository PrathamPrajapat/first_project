 <div class="card-footer text-muted text-center">
      All Right Reserved &copy; Mom's Kitchen
  </div>
</div>