<div class="jumbotron jumbotron-fluid" style="background-image: url('./images/bg.jpg')">
  <div class="container">
    <h1 class="display-4 text-center">WELCOME TO MOM'S KITCHEN</h1>
    <p class="lead text-center">Where every flavor tells a story</p>
  </div>
</div>