<div class="slider">
<marquee direction="right">
    <h5>**Flat 50% off on any order for new customers**</h5>
</marquee>
</div>