<?php
$connect = mysqli_connect("localhost", "root", "", "foodweb");
{
    if(!$connect)
    {
        die("Connection Failed");
    }
}
?>