<div id='contact'>
    <div class="container">
    <h2 class="contactus text-center">Have Some Question?</h2>
        <form>
  <div class="form-group">
    <label for="fname">Full Name</label>
    <input type="text" class="form-control" id="fname" name="fname" placeholder="Enter Your Full Name Here">
  </div>
            <div class="form-group">
    <label for="emailid">Email address</label>
    <input type="email" class="form-control" id="emailid" name="emailid" placeholder="name@example.com">
  </div>
            <div class="form-group">
    <label for="mobileno">Mobile No</label>
    <input type="text" class="form-control" id="mobileno" name="mobileno">
  </div>
  <div class="form-group">
    <label for="textarea">Your Query</label>
    <textarea class="form-control" id="textarea" rows="3" placeholder="Your Questions...."></textarea>
  </div>
            <button type="submit" class="btn btn-primary" id="question" name="question">Submit</button>
</form>
    </div>
</div>
<br>
<br>